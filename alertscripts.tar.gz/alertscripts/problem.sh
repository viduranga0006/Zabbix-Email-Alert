#!/bin/bash

cd /usr/lib/zabbix/alertscripts

##############################################
# Colour CODE
##############################################

RED="#ff5c33" #Disaster
YELLOW="#FFE333" #Warning
ORANGE="#FFA833" #Average
BLUE="#33C4FF" #Info
GREEN="#0F9B48"
WHITE="#FFFFFF"
_date=`date --date="today" +%Y-%m-%d`

SENDER="Zabbix-Alert<zabbix-alert@mycompany.com>" # Sender Email Address
mail_status=1
TO=$3

echo $2 >> ./logs/problem-"$_date".txt
echo "----------------------------------------------------" >> ./logs/problem-"$_date".txt

SUBJECT=$1

_start_time=$(echo $2 | cut -d'' -f1)
_name=$(echo $2 | cut -d'' -f2 | cut -d':' --complement -s -f1)
_host=$(echo $2 | cut -d'' -f3 | cut -d' ' -f3)
_ip=$(echo $2 | cut -d'' -f4 | cut -d' ' -f3)
_severity=$(echo $2 | cut -d'' -f5 | cut -d' ' -f3)
_problem_id=$(echo $2 | cut -d'' -f7 | cut -d' ' -f5)
_status=$(echo $2 | cut -d'' -f8 | cut -d' ' -f3)
_trigger_id=$(echo $2 | cut -d'' -f9 | cut -d' ' -f4)
_last_value=$(echo $2 | cut -d'' -f10 | cut -d':' --complement -s -f1 | cut -d' ' --complement -s -f1)
_item_id=$(echo $2 | cut -d'' -f11 | cut -d':' -f2 | cut -d' ' -f2)
_graphic_id=$(echo $2 | cut -d'' -f12)

#############################################
# Argument to pass to the script and its manipulation
#############################################

# Get graphid

GRAPHID=$(echo $_graphic_id | grep -o -E "(Item Graphic: \[[0-9]{7}\])|(Item Graphic: \[[0-9]{6}\])|(Item Graphic: \[[0-9]{5}\])|(Item Graphic: \[[0-9]{4}\])|(Item Graphic: \[[0-9]{3}\])")
GRAPHID=$(echo $GRAPHID | grep -o -E "([0-9]{7})|([0-9]{6})|([0-9]{5})|([0-9]{4})|([0-9]{3})")

#############################################
# Zabbix address
#############################################

ZBX_URL="https://mycompany.com/zabbix" # ZAbbix URL

##############################################
# Zabbix credentials to login
##############################################

USERNAME="Admin" # Zabbix Username
PASSWORD="password" # Zabbix Password

#############################################
# Zabbix versione >= 3.4.1
# 0 for no e 1 for yes
#############################################

ZABBIXVERSION34="1"

# If the GRAPHID variable is not compliant not send the graph

case $GRAPHID in
        ''|*[!0-9]*) SEND_GRAPH=0 ;;
        *) SEND_GRAPH=1 ;;
esac

#############################################
# To disable graph sending set SEND_GRAPH = 0, otherwise SEND_GRAPH = 1
#############################################

SEND_GRAPH=1

# If the GRAPHID variable is not compliant, not send the graph

case $GRAPHID in
    ''|*[!0-9]*) SEND_GRAPH=0 ;;
esac

##############################################
# Graph setting
##############################################

WIDTH=1024
CURL="/usr/bin/curl"
COOKIE="/tmp/$_item_id-graph_cookie-$(date "+%Y.%m.%d-%H.%M.%S")"
PNG_PATH="/tmp/$_item_id-graph-$(date "+%Y.%m.%d-%H.%M.%S").png"

############################################
# Width of graphs in time (second) Ex: 10800sec/3600sec=3h
############################################

PERIOD=3600

############################################
# Send graph
############################################

# If SEND_GRAPH=1 send the graph
if [ $(($SEND_GRAPH)) -eq '1' ]; then

        # First, login to Zabbix GUI
        # (check if there is "Sign in" in the button to login, otherwise change the web parameters here

        ${CURL} -k -s -S --max-time 5 -c ${COOKIE} -b ${COOKIE} -d "name=${USERNAME}&password=${PASSWORD}&autologin=1&enter=Sign%20in" ${ZBX_URL}"/index.php"

        # In some case is useful send personalized graph instead of graph of last data of item
        # So, put in TEXT variable a personalized GRAPHID, that here is managed differently from classic item GRAPHID
        if [ "${GRAPHID}" == "000001" ]; then
                GRAPHID="00002";
                ${CURL} -k -s -S --max-time 5 -c ${COOKIE} -b ${COOKIE} -d "graphid=${GRAPHID}&period=${PERIOD}&width=${WIDTH}" ${ZBX_URL}"/chart2.php" -o "${PNG_PATH}";
        elif [ "${GRAPHID}" == "000002" ]; then
                GRAPHID="00003";
                ${CURL} -k -s -S --max-time 5 -c ${COOKIE}  -b ${COOKIE} -d "graphid=${GRAPHID}&period=${PERIOD}&width=${WIDTH}" ${ZBX_URL}"/chart2.php" -o "${PNG_PATH}";
        elif [ "${GRAPHID}" == "000003" ]; then
                GRAPHID="00004";
                ${CURL} -k -s -S --max-time 5 -c ${COOKIE}  -b ${COOKIE} -d "graphid=${GRAPHID}&period=${PERIOD}&width=${WIDTH}" ${ZBX_URL}"/chart2.php" -o "${PNG_PATH}";
        else
                # If no personalized GRAPHID passed, download the image of graph of item
                if [ "${ZABBIXVERSION34}" == "1" ]; then
                        ${CURL} -k -s -S --max-time 5 -c ${COOKIE}  -b ${COOKIE} -d "itemids=${GRAPHID}&period=${PERIOD}&width=${WIDTH}&profileIdx=web.item.graph" ${ZBX_URL}"/chart.php" -o "${PNG_PATH}";
                else
                        ${CURL} -k -s -S --max-time 5 -c ${COOKIE}  -b ${COOKIE} -d "itemids=${GRAPHID}&period=${PERIOD}&width=${WIDTH}" ${ZBX_URL}"/chart.php" -o "${PNG_PATH}";
                fi
        fi

fi

############################################
# Set Severity Color Code
############################################

if [ $_severity == "Disaster" ];
then
        _COLOUR=$RED

elif [ $_severity == "Warning" ];
then
        _COLOUR=$YELLOW

elif [ $_severity == "Average" ];
then
        _COLOUR=$ORANGE

elif [ $_severity == "Information" ];
then
        _COLOUR=$BLUE

elif [ $_severity == "High" ];
then
	_COLOUR=$RED

else
        _COLOUR=$BLUE
fi


###########################################
# Send Mail
###########################################

BODY=$(echo "Dears, <br> <br> System alert has been detected. $_start_time <br> <br> <b>Problem Name: </b> $_name <br> <b>Host:</b> $_host <br> <b>IP:</b> $_ip <br> <br> <b>Severity: <font color=$_COLOUR> $_severity </font> <br> Last Value:</b> <font color=$WHITE>'</font>$_last_value<font color=$WHITE>'</font> <br> <b> Problem ID:</b> $_problem_id <br> <b> Status: <font color=$RED> $_status </font> </b> <br> <br> <b>Graph URL: <a href="$ZBX_URL"/history.php?action=showgraph&fullscreen=1&itemids[]=$_item_id>Click Here</a> </b> <br> <b>Event URL: <a href="$ZBX_URL"/tr_events.php?triggerid=$_trigger_id&eventid=$_problem_id>Click Here</a> <br> <br> Best Regards,</b> <br> Zabbix Agent.")

#SUBJECT="[$_severity] :$_title"

echo "$SENDER , $TO , $SUBJECT , $BODY " >> ./logs/mail-"$_date".txt 
./sendEmail -o message-content-type=html -f $SENDER -t $TO -u $SUBJECT -m $BODY -a $PNG_PATH >> ./logs/mail-"$_date".txt


############################################
# Clean file used in the script execution
############################################

rm -f ${COOKIE}

rm -f ${PNG_PATH}

exit 0
