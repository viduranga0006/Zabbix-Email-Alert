#!/bin/bash

cd /usr/lib/zabbix/alertscripts
RED="#ff5c33" #Disaster
YELLOW="#FFE333" #Warning
ORANGE="#FFA833" #Average
BLUE="#33C4FF" #Info
GREEN="#0F9B48"

_date=`date --date="today" +%Y-%m-%d`

echo $2 >> ./logs/acknowledged-"$_date".txt
echo "----------------------------------------------------" >> ./logs/acknowledged-"$_date".txt

SENDER="Zabbix-Alert<zabbix-alert@mycompany.com>"
mail_status=1
TO=$3
SUBJECT=$1

_acknowledged_time=$(echo $2 | cut -d'' -f1)
_acknowledged_message=$(echo $2 | cut -d'' -f2)
_name=$(echo $2 | cut -d'' -f4 | cut -d':' --complement -s -f1)
_host=$(echo $2 | cut -d'' -f5 | cut -d' ' -f3)
_ip=$(echo $2 | cut -d'' -f6 | cut -d' ' -f3)
_severity=$(echo $2 | cut -d'' -f7 | cut -d' ' -f3)
_status=$(echo $2 | cut -d'' -f8 | cut -d':' -f2)
_problem_id=$(echo $2 | cut -d'' -f9 | cut -d' ' -f5)
_last_value=$(echo $2 | cut -d'' -f10 | cut -d':' --complement -s -f1 | cut -d' ' --complement -s -f1)

if [ $_severity == "Disaster" ];
then
	_COLOUR=$RED

elif [ $_severity == "Warning" ];
then
	_COLOUR=$YELLOW

elif [ $_severity == "Average" ];
then
	_COLOUR=$ORANGE

elif [ $_severity == "Information" ];
then
	_COLOUR=$BLUE

elif [ $_severity == "High" ];
then
        _COLOUR=$RED

else
	_COLOUR=$BLUE
fi

BODY=$(echo "Dears, <br> <br> $_acknowledged_time <br> <br> <b> $_acknowledged_message </b> <br> <br> <b>Problem Name: </b> $_name <br> <b>Host:</b> $_host <br> <b>IP:</b> $_ip <br> <br> <b> Severity: <font color=$_COLOUR> $_severity </font> </b> <br> <b> Problem ID:</b> $_problem_id <br> <b> Last Value:</b> <font color=$WHITE>'</font>$_last_value<font color=$WHITE>'</font> <br> <b> Status: <font color=$RED> $_status </font> </b>  <br> <br> <b> Best Regards,</b> <br> Zabbix Agent.")

#SUBJECT="[$_severity] : $1"
#BODY=`cat ./BODY.txt`
#echo "$2" > ./BODY.txt

./sendEmail -o message-content-type=html -f $SENDER -t $TO -u $SUBJECT -m $BODY

exit 0
